# Shadow Mirror — Complete Research Archive

**Author of record:** Omar Moawad
**Affiliation:** The American University in Cairo, AUC Avenue, P.O. Box 74, New Cairo 11835, Egypt
**Programme:** 18 sessions, complete · **Package:** `shadow_mirror` v1.3.0 · **Archive date:** 25 July 2026

---

## Start here

If you have five minutes, open **`tracker/shadow_mirror_program_tracker.html`** in a browser. It is the
whole programme on one page.

If you have an hour, read the two papers in `papers/`, then `sessions/SESSION_13_ADVERSARIAL_REVIEW.md`
— which attacks them.

If you want to run something:

```bash
cd code/shadow_mirror_v1.3.0
pytest -q                 # 707 passed, 2 xfailed
python demo.py
```

No dependencies to install. The package has **zero runtime dependencies** by design — that is an
auditability commitment, not an aesthetic one, and it is why NetworkX was removed in Session 4.

---

## What this is

An architecture for reflective human–AI interaction, and two papers about it.

The system observes what a person says they want and what they do, and models the gap. The central
design claim is that when those disagree, the honest output is frequently a **refusal** rather than a
better-hedged guess — because approach under stated reluctance is produced by hidden preference, and it
is *also* produced by compliance under perceived pressure, and the two are not distinguishable from the
surface signal.

**Measured result:** 0 of 800 simulated threat episodes misread (95% upper bound 0.37% by the rule of
three) against 42.9% for a mismatch-only reader and 75.1% for an arousal-as-desire reader.

**Measured cost:** a supervised four-channel classifier, given ground-truth labels, beats us at low
channel separation — 5.0% against our 29.7%. That is in the paper because a reviewer would find it
otherwise. The defence is that those labels do not exist in deployment, which makes it an upper bound
on what any supervised method could reach rather than an available alternative.

---

## Contents

### `papers/`

| File | What it is |
|---|---|
| `P1_ACM_TiiS_draft.md` | **Invariants You Can Run** — the architecture paper. 58 refs. Target: ACM TiiS |
| `P2_AIES_FAccT_draft.md` | **Refusal as a Safety Mechanism** — the ethics paper. 56 refs. Target: AIES / FAccT |
| `FORMAL_APPENDIX_corrected.md` | Notation, operator signatures, belief axioms, complexity table |
| `APPENDICES_C_D_rebuilt.md` | Supporting appendices |
| `bibliography.json` | All 105 manuscript references, machine-checked, every one with a resolvable identifier |
| `figures/` | Six figures, PNG and PDF |

**P2 is the stronger submission.** It has a measured harm rate, an adversarial check that partly
undermines its own headline, and no claims about people.

Each paper ends with an **Outstanding Work appendix** listing only what has no available substitute —
every entry was searched for before it was listed, and the accompanying table records what the search
*did* resolve.

### `code/shadow_mirror_v1.3.0/`

The package. 707 tests passing, 2 declared `xfail`s recording unimplemented operators.

| Module | What it does |
|---|---|
| `engine.py` | Inference over stated desire, behaviour, arousal and avoidance |
| `urg.py` | Unified Reflective Graph — typed nodes, multi-parent provenance, contradiction as a first-class edge |
| `beliefs.py` | Order-invariant, exactly retractable belief revision |
| `inquiry.py` | Expected information gain over candidate questions |
| `invariants.py` | **Eleven** architectural properties as callable checks |
| `credible.py` | Credible sets, soft-EM person offsets with an identifiability guard |
| `deployment.py` | Refuses the biometric stream outside self/consented contexts |
| `ledger.py` | Hash-chained append-only consent; refuses retroactive grants |
| `formation.py` | Declared-only personhood, instrument registry, twelve named refusals |
| `route_a.py` | Loaders and analyses for three public corpora |

**Mutation score: 59.9%** (5,114 mutants, 2,319 killed, 1,549 survived). Reported rather than tuned.
Survivors concentrate in the engine, the pattern layer and the invariant checks themselves.

### `submission/`

| File | Status |
|---|---|
| `AUC_IRB_PACKET.md` | Full protocol, consent form, PDPL/CAPMAS/CITI sequencing. **Not submitted.** `[YOU]` markers show what only you can fill |
| `INSTRUMENT_PERMISSION_EMAILS.md` | Four drafted letters. **Two are now unnecessary** — Session 17 found free substitutes for the PVQ-RR and 3D-WS requests |

### `sessions/`

Eighteen session reports plus `PROGRAM_PLAN.md` and `STATE.json`. `STATE.json` is the machine-readable
programme state: the full 34-item defect register, verified citations, ground rules, blocking questions.

The ones worth reading on their own:

- **`SESSION_13_ADVERSARIAL_REVIEW.md`** — fourteen attacks on the papers. Five conceded, four rebutted
  with new evidence, five fixed in the text. One found a result that weakened the headline.
- **`SESSION_14B_DATA_FEASIBILITY.md`** — the honest answer on whether existing data can validate the
  safety claim. Roughly forty datasets assessed; it cannot.
- **`SESSION_15_FORMATION_MODEL.md`** — why a request to infer people's background, maturity and purpose
  was answered by building one fifth of it and refusing four fifths.
- **`SESSION_17_WORKAROUND_HUNT.md`** — eleven candidate blockers searched; six dissolved, five survived.

---

## The ground rules

These governed every session and are worth stating, because most of what is unusual about this archive
follows from them.

1. **No fabricated evidence, ever.** Every number in a paper is produced by code in this repository that
   a reviewer can run.
2. No human-subjects data is collected in these sessions. Simulated participants are never called a
   result.
3. No text enters a manuscript in the past tense describing work not performed.
4. **No number enters a manuscript unless a file in the repository produces it AND the person writing
   the sentence has run that file.** (Violated twice, both caught: D-33, D-34.)
5. No additional evidence channel is added until the guard **refuses** rather than silently degrading.
6. **No citation enters a manuscript unless confirmed against a live source** with a resolvable
   identifier. Failure to confirm is reported as failure, never filled in from memory.
7. No instrument is administered whose permission terms are unconfirmed, and no item text is bundled
   with the software. An unconfirmed licence is a refusal, not a warning.
8. **Nothing about a person enters a model unless that person declared it or self-completed the
   instrument it came from.** Absence is not refusal — a refusing method must exist and explain itself.
9. **Nothing is recorded as pending until a search for a substitute has come back empty.** The pending
   list is the residue of a search, not a wishlist.

---

## Five things found by measurement rather than by intent

Listed because they are the best argument for the method, and because each was slightly embarrassing.

1. **Provenance as a scalar dropped every parent but one.** The formalism said "attribute" where the
   literature had said "set" three decades earlier. Invariant II caught it.
2. **A clamping step that looked like numerical hygiene destroyed commutativity and retractability.**
   Belief order-invariance went from 0.0396/0.9900 across permutations to agreement at 1e-12.
3. **Invariant X false-positived on our own shipped output.** The defect was in the check, not the
   output. Reported in P1 §3.4 as the argument for the method.
4. **Retroactive consent was already impossible and nobody designed it.** Found by a failing test. It
   falls out of asking *what was granted at time T* rather than *is there a grant*.
5. **Mutating an invariant's own identifier survived.** Nothing asserted that a check returns the
   invariant it claims to be — a catalogue of eleven named properties that could have been silently
   renamed. Found by mutation testing in Session 17.

---

## What is not done

Five items with no available substitute, in each paper's Outstanding Work appendix:

1. **The threat-confound claim requires primary collection.** No public corpus has the four-way
   intersection of stated stance, contradictable choice, time-locked arousal and a coercion
   manipulation.
2. **No instrument in the battery is validated in an Egyptian sample.** The Arabic evidence is Lebanese,
   Saudi, Omani, Jordanian, Palestinian, Qatari, Moroccan.
3. **Two constructs have no free replacement** — an eight-theme Eriksonian inventory, and purpose beyond
   the Meaning in Life Questionnaire.
4. **No party outside this project has executed the software.** None of TiiS, FAccT or AIES runs an
   artifact track. CODECHECK is the available route and has not been used.
5. **Invariant X and the question generator are syntactic proxies** for semantic properties. A research
   problem, not an unfinished task.

Ordinary unfinished work is deliberately excluded from those appendices: two `xfail` operators, a read
path still linear per consultation, a candidate belief state for monotonic drift, and 1,549 surviving
mutants. None is blocked on anything external.

---

## Before submission

| | |
|---|---|
| Corresponding email, and a department if you have one | The only gap in the author block |
| Three dataset downloads | Two are small: BIRAFFE2 needs 35 MB, Urban Appraisal 16 MB |
| Urban Appraisal rating polarity | From the BeMoBIL analysis code. The loader refuses until supplied |
| Two instrument permissions | Bronk (Claremont Purpose Scale), Darling-Fisher (MEPSI) |
| CITI certification and a supervisor | Only if the primary study proceeds |

---

## Citation

> Moawad, O. (2026). *Shadow Mirror: a reference architecture for reflective human–AI interaction.*
> The American University in Cairo.

The software is a research instrument. **It is not suitable for clinical, educational, employment,
credit, insurance or policing use**, and it refuses to run in institutional deployment contexts.
